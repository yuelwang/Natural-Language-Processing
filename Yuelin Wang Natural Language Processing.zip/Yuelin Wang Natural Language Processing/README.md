# Setup Guide
Open the "LLM Natural Language Processing" Jupyter Notebook, then run the cells. I didn't include the finished vocabulary dictionary and the visualizations, thus please run the Jupyter Notebook and the files will be generated. In addition, the documentation includes explanations about this project.

# Read Me Task 1
The top three positive employees (across all the months) are lydia.delgado@enron.com, patti.thompson@enron.com, and eric.bass@enron.com. The negative are bobette.riner@ipgdirect.com, sally.beck@enron.com, and kayne.coulter@enron.com.

# Read Me Task 2
As of 12/31/2011, in the past 30 days, there's no list of employees having flight risks.

# Read Me Task 3
One of the insight I gain in this natural language processing project is that tokenizing both the email subject and content is better than only content. The statistical learning model are more accurate in this way.

# Some Personal Message from the Submitter of this Project
I just want to say that I know that my answers may not be correct, and I know that there's many rooms for improvement. This project is rather difficult for me. However, I will try my best to study and design statistical learning model if I'm accepted. I've been constantly spending time and effort over the night working extra time to learn and finish this LLM project, and I will still spend time and effort the same way and more in the future. In the end, no matter whether I pass or not, thank you for your time.